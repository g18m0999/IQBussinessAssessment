﻿using ChuckNorrisAPI.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ChuckNorrisAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class FavouriteJokesController : ControllerBase
    {
        private readonly IFavouriteJokeRepository _favouriteJokeRepository;

        public FavouriteJokesController(IFavouriteJokeRepository favouriteJokeRepository)
        {
            _favouriteJokeRepository = favouriteJokeRepository;
        }

        [HttpGet]
        public async Task<IEnumerable<FavouriteJoke>> Get()
        {
            return await _favouriteJokeRepository.GetFavouriteJokes();
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<FavouriteJoke>> GetById(int id)
        {
            var joke = await _favouriteJokeRepository.GetById(id);
            if (joke == null)
            {
                return NotFound();
            }
            return joke;
        }

        [HttpPost]
        [Route("LikeJoke")]
        public async Task<ActionResult<FavouriteJoke>> Create(FavouriteJoke joke)
        {
            await _favouriteJokeRepository.LikeJoke(joke);
            return CreatedAtAction(nameof(GetById), new { id = joke.Id }, joke);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var joke = await _favouriteJokeRepository.GetById(id);
            if (joke == null)
            {
                return NotFound();
            }
            await _favouriteJokeRepository.DeleteJoke(id);
            return NoContent();
        }



    }
}
