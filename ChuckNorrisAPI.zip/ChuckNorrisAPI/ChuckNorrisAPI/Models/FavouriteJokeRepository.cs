﻿using Microsoft.EntityFrameworkCore;

namespace ChuckNorrisAPI.Models
{
    public class FavouriteJokeRepository: IFavouriteJokeRepository
    {
        private readonly ChuckNorrisDbContext _dbContext;

        public FavouriteJokeRepository(ChuckNorrisDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<IEnumerable<FavouriteJoke>> GetFavouriteJokes()
        {
            return await _dbContext.Set<FavouriteJoke>().ToListAsync();

        }
        public async Task<FavouriteJoke> GetById(int id)
        {
            return await _dbContext.Set<FavouriteJoke>().FindAsync(id);
        }

        public async Task LikeJoke(FavouriteJoke joke)
        {
            joke.LikedOn = DateTime.UtcNow;
            await _dbContext.Set<FavouriteJoke>().AddAsync(joke);
            await _dbContext.SaveChangesAsync();
        }

        public async Task DeleteJoke(int id)
        {
            var joke = await GetById(id);
            _dbContext.Set<FavouriteJoke>().Remove(joke);
            await _dbContext.SaveChangesAsync();
        }
    }
}
