﻿using System;
using System.Collections.Generic;

namespace ChuckNorrisAPI.Models;

public partial class FavouriteJoke
{
    public int Id { get; set; }

    public string TheJoke { get; set; } = null!;

    public DateTime LikedOn { get; set; }
}
