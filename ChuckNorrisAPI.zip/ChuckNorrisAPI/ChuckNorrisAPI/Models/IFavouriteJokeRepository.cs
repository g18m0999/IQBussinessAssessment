﻿namespace ChuckNorrisAPI.Models
{
    public interface IFavouriteJokeRepository
    {
        Task<IEnumerable<FavouriteJoke>> GetFavouriteJokes();

        Task<FavouriteJoke> GetById(int id);
        Task LikeJoke(FavouriteJoke joke);
        Task DeleteJoke(int id);

    }
}
